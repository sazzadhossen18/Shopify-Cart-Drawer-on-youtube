
let interval = setInterval(function () {
  let apElements = document.querySelector('#avpoptions-container');
  if (apElements){
    $('.product-form--atc').before($('#avpoptions-container'));
    clearInterval(interval);
  }
}, 100);

function forceQuitInterval(){
  clearInterval(interval);
}

setTimeout(forceQuitInterval, 10000)